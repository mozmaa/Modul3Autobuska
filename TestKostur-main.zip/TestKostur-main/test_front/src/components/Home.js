const Home = () => {
    return (
        <h1>Test Home page</h1>
    )
}

export default Home